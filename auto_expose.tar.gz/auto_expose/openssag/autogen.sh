#!/bin/bash

autoreconf --force --install
